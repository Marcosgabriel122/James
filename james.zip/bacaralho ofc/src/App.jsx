import { useState, useEffect } from 'react'
import { onAuthStateChanged } from 'firebase/auth'
import { doc, getDoc } from 'firebase/firestore'
import { auth, db } from './firebaseConection'

import Login from './pages/Login'
import Cadastro from './pages/Cadastro'
import Dashboard from './pages/Dashboard'
import Cliente from './pages/Cliente'

// Busca o papel do usuário na coleção "usuarios": 'admin', 'usuario' ou 'cliente'.
// Se não achar (ou der erro), devolve 'cliente', que é o papel com menos acesso.
async function buscarPapel(uid) {
  try {
    const snapshot = await getDoc(doc(db, 'usuarios', uid))
    if (snapshot.exists() && snapshot.data().papel) {
      return snapshot.data().papel
    }
  } catch (error) {
    console.error('Erro ao buscar o papel do usuário:', error)
  }
  return 'cliente'
}

function App() {
  const [usuario, setUsuario] = useState(null)       // usuário logado (ou null)
  const [papel, setPapel] = useState(null)           // 'admin', 'usuario' ou 'cliente'
  const [carregando, setCarregando] = useState(true)  // true enquanto o Firebase verifica a sessão
  const [pagina, setPagina] = useState('login')       // 'login' ou 'cadastro'

  // Fica "ouvindo" o login/logout. Roda quando o app abre e toda vez que o estado muda.
  // Quando tem alguém logado, busca também o papel dele antes de liberar a tela.
  useEffect(() => {
    const parar = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setPapel(await buscarPapel(user.uid))
      } else {
        setPapel(null)
      }
      setUsuario(user)
      setCarregando(false)
    })
    return parar // para de ouvir quando o componente sai da tela
  }, [])

  if (carregando) {
    return <p>Carregando...</p>
  }

  // Na tela de cadastro, mostramos o formulário mesmo que o Firebase já tenha logado o usuário.
  // Quando o cadastro termina, a página volta para 'login' e, como já existe usuário logado,
  // o código abaixo abre a tela certa para o papel dele.
  if (pagina === 'cadastro') {
    return <Cadastro concluido={() => setPagina('login')} irParaLogin={() => setPagina('login')} />
  }

  if (usuario) {
    // Quem cadastra e gerencia os carros (admin e usuário) vê o Dashboard
    if (papel === 'admin' || papel === 'usuario') {
      return <Dashboard usuario={usuario} />
    }
    // Clientes veem a página própria deles
    return <Cliente usuario={usuario} />
  }

  return <Login irParaCadastro={() => setPagina('cadastro')} />
}

export default App