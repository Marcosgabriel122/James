import { useState } from 'react'
import { collection, getDocs, query, orderBy } from 'firebase/firestore'
import { db } from '../firebaseConection'
import '../styles/Relatorio.css'


function formatarData(timestamp) {
  if (!timestamp || !timestamp.toDate) {
    return 'Sem data'
  }
  return timestamp.toDate().toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })
}


function dinheiro(valor) {
  return Number(valor || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
}

function Relatorio() {
  const [vendas, setVendas] = useState([])         
  const [pesquisa, setPesquisa] = useState('')     
  const [gerado, setGerado] = useState(false)      
  const [carregando, setCarregando] = useState(false)
  const [erro, setErro] = useState('')

  
  async function gerarRelatorio() {
    setErro('')
    setCarregando(true)

    try {
      const consulta = query(collection(db, 'vendas'), orderBy('vendidoEm', 'desc'))
      const snapshot = await getDocs(consulta)

      setVendas(snapshot.docs.map((d) => ({ id: d.id, ...d.data() })))
      setGerado(true)
    } catch (error) {
      setErro('Erro ao gerar o relatório: ' + (error.code || error.message))
    } finally {
      setCarregando(false)
    }
  }

  
  const texto = pesquisa.trim().toLowerCase()
  const filtradas = vendas.filter((venda) => {
    const tudo = [formatarData(venda.vendidoEm), venda.compradorNome, venda.compradorEmail,
      venda.formaPagamento, venda.marca, venda.modelo, venda.ano, venda.motorizacao,
      venda.cor, venda.combustivel, venda.condicao].join(' ').toLowerCase()
    return tudo.includes(texto)
  })

  // Soma dos preços das vendas que aparecem na tela
  const total = filtradas.reduce((soma, venda) => soma + Number(venda.preco || 0), 0)

  return (
    <div>
      
      <div className="rel-topo">
        <h1>Relatório de vendas</h1>

        <div className="rel-pesquisa">
          <input
            type="text"
            placeholder="Pesquisa"
            value={pesquisa}
            onChange={(e) => setPesquisa(e.target.value)}
          />
          <span>🔍</span>
        </div>
      </div>

      
      <div className="rel-gerar">
        <button onClick={gerarRelatorio} disabled={carregando}>
          {carregando ? 'Gerando...' : 'Gerar relatório'}
        </button>
      </div>

      {erro && <p className="rel-erro">{erro}</p>}
      {gerado && vendas.length === 0 && !erro && <p>Nenhuma venda registrada ainda.</p>}
      {gerado && vendas.length > 0 && filtradas.length === 0 && <p>Nenhuma venda encontrada.</p>}

      {filtradas.length > 0 && (
        <p className="rel-resumo">
          <strong>{filtradas.length}</strong> {filtradas.length === 1 ? 'venda' : 'vendas'} |
          Total vendido: <strong>{dinheiro(total)}</strong>
        </p>
      )}

      
      {filtradas.map((venda) => (
        <div className="rel-item" key={venda.id}>
          <div className="rel-data">{formatarData(venda.vendidoEm)}</div>

          <div className="rel-comprador">
            <p><strong>Comprador</strong></p>
            <p>{venda.compradorNome || '(sem nome)'}</p>
            <p>{venda.compradorEmail}</p>
            {venda.formaPagamento && <p>Pagamento: {venda.formaPagamento}</p>}
          </div>

          <div className="rel-carro">
            <p><strong>{venda.marca} {venda.modelo}</strong> ({venda.ano})</p>
            <p>{venda.motorizacao} | {venda.cor} | {venda.combustivel}</p>
            <p>{Number(venda.quilometragem).toLocaleString('pt-BR')} km | {venda.condicao}</p>
            <p>Preço: {dinheiro(venda.preco)}</p>
          </div>
        </div>
      ))}
    </div>
  )
}

export default Relatorio