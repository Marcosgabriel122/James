import { useState } from 'react'
import { criarCarro, atualizarCarro } from '../carrosService'
import '../styles/CadastroCarro.css'


const vazio = {
  marca: '',
  modelo: '',
  ano: '',
  motorizacao: '',
  cor: '',
  combustivel: '',
  quilometragem: '',
  condicao: '',
  preco: '',
  descricao: '',
  status: 'disponivel', 
}


function formDoCarro(carro) {
  return {
    marca: carro.marca || '',
    modelo: carro.modelo || '',
    ano: String(carro.ano ?? ''),
    motorizacao: carro.motorizacao || '',
    cor: carro.cor || '',
    combustivel: carro.combustivel || '',
    quilometragem: String(carro.quilometragem ?? ''),
    condicao: carro.condicao || '',
    preco: String(carro.preco ?? ''),
    descricao: carro.descricao || '',
    status: carro.status || 'disponivel',
  }
}


// - sem a prop "carro": cadastra um veículo novo
// - com a prop "carro": edita o veículo que veio da lista
function CadastroCarro({ usuario, carro, voltar }) {
  const [form, setForm] = useState(carro ? formDoCarro(carro) : vazio) 
  const [erro, setErro] = useState('')
  const [sucesso, setSucesso] = useState('')
  const [salvando, setSalvando] = useState(false)

 
  function mudar(e) {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

 
  function limpar() {
    setForm(vazio)
    setErro('')
    setSucesso('')
  }

  
  async function salvar(e) {
    e.preventDefault() // evita recarregar a página
    setErro('')
    setSucesso('')
    setSalvando(true)

    
    const dados = {
      marca: form.marca.trim(),
      modelo: form.modelo.trim(),
      ano: Number(form.ano),
      motorizacao: form.motorizacao.trim(),
      cor: form.cor.trim(),
      combustivel: form.combustivel,
      quilometragem: Number(form.quilometragem),
      condicao: form.condicao,
      preco: Number(form.preco),
      descricao: form.descricao.trim(),
      status: form.status,
    }

    try {
      if (carro) {
        // Edição: atualiza só esses campos no documento que já existe
        await atualizarCarro(carro.id, dados)
        voltar() 
      } else {
        // Cadastro novo: cria um documento na coleção "carros"
        await criarCarro(dados)
        setForm(vazio)
        setSucesso('Veículo salvo com sucesso!')
      }
    } catch (error) {
      if (error.code === 'permission-denied' || error.message.startsWith('Sem permissão')) {
        setErro('Sem permissão para salvar.')
      } else {
        setErro('Erro ao salvar: ' + (error.code || error.message))
      }
    } finally {
      setSalvando(false)
    }
  }

  return (
    <div>
      <h1 className="carro-titulo">{carro ? 'Editar veículo' : 'Cadastro de veículos'}</h1>

      {erro && <p className="carro-erro">{erro}</p>}
      {sucesso && <p className="carro-sucesso">{sucesso}</p>}

      <form onSubmit={salvar}>
        <div className="carro-campos">
          <div>
            <label htmlFor="marca">Marca</label>
            <input type="text" id="marca" name="marca" value={form.marca} onChange={mudar} required />
          </div>

          <div>
            <label htmlFor="modelo">Modelo</label>
            <input type="text" id="modelo" name="modelo" value={form.modelo} onChange={mudar} required />
          </div>

          <div>
            <label htmlFor="ano">Ano</label>
            <input type="number" id="ano" name="ano" min="1900" max="2100" value={form.ano} onChange={mudar} required />
          </div>

          <div>
            <label htmlFor="motorizacao">Motorização</label>
            <input type="text" id="motorizacao" name="motorizacao" placeholder="Ex.: 1.0, 2.0 turbo" value={form.motorizacao} onChange={mudar} required />
          </div>

          <div>
            <label htmlFor="cor">Cor</label>
            <input type="text" id="cor" name="cor" value={form.cor} onChange={mudar} required />
          </div>

          <div>
            <label htmlFor="combustivel">Combustível</label>
            <select id="combustivel" name="combustivel" value={form.combustivel} onChange={mudar} required>
              <option value="">Selecione</option>
              <option value="Flex">Flex</option>
              <option value="Gasolina">Gasolina</option>
              <option value="Etanol">Etanol</option>
              <option value="Diesel">Diesel</option>
              <option value="GNV">GNV</option>
              <option value="Híbrido">Híbrido</option>
              <option value="Elétrico">Elétrico</option>
            </select>
          </div>

          <div>
            <label htmlFor="quilometragem">Quilometragem</label>
            <input type="number" id="quilometragem" name="quilometragem" min="0" value={form.quilometragem} onChange={mudar} required />
          </div>

          <div>
            <label htmlFor="condicao">Condição</label>
            <select id="condicao" name="condicao" value={form.condicao} onChange={mudar} required>
              <option value="">Selecione</option>
              <option value="Ruim">Ruim</option>
              <option value="Regular">Regular</option>
              <option value="Bom">Bom</option>
              <option value="Ótimo">Ótimo</option>
              <option value="Novo">Novo</option>
            </select>
          </div>

          <div>
            <label htmlFor="preco">Preço (R$)</label>
            <input type="number" id="preco" name="preco" min="0" step="0.01" value={form.preco} onChange={mudar} required />
          </div>

          <div>
            <label htmlFor="status">Situação</label>
            <select id="status" name="status" value={form.status} onChange={mudar} required>
              <option value="disponivel">Disponível</option>
              <option value="indisponivel">Não disponível</option>
              <option value="revisao">Em revisão</option>
              {/* Carro já vendido (registrado pelo sistema): aparece só para mostrar a situação, sem poder escolher */}
              {form.status === 'vendido' && <option value="vendido" disabled>Vendido</option>}
            </select>
          </div>

          <div className="carro-descricao">
            <label htmlFor="descricao">Descrição / observação</label>
            <textarea id="descricao" name="descricao" rows="5" value={form.descricao} onChange={mudar} />
          </div>
        </div>

        <div className="carro-botoes">
          <button type="submit" disabled={salvando}>{salvando ? 'Salvando...' : 'Salvar'}</button>
          <button type="button" onClick={voltar}>Cancelar</button>
          <button type="button" onClick={limpar}>Limpar tudo</button>
        </div>
      </form>
    </div>
  )
}

export default CadastroCarro