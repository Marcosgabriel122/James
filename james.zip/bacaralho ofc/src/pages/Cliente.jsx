import { useState, useEffect } from 'react'
import { signOut } from 'firebase/auth'
import { collection, getDocs, query, orderBy } from 'firebase/firestore'
import { auth, db } from '../firebaseConection'
import { situacaoDe } from '../status'
import { comprarCarro } from '../carrosService'
import CarroCard from '../components/CarroCard'
import ModalPagamento from '../components/ModalPagamento'
import ModalFinanciamento from '../components/ModalFinanciamento'
import '../styles/Cliente.css'


function Cliente({ usuario }) {
  const [carros, setCarros] = useState([])          
  const [pesquisa, setPesquisa] = useState('')     
  const [carregando, setCarregando] = useState(true)
  const [erro, setErro] = useState('')
  const [selecionado, setSelecionado] = useState(null) 
  const [modal, setModal] = useState(null)          

  // Busca todos os carros da coleção "carros", do mais novo para o mais antigo
  async function buscarCarros() {
    setErro('')
    try {
      const consulta = query(collection(db, 'carros'), orderBy('criadoEm', 'desc'))
      const snapshot = await getDocs(consulta)
    
      setCarros(snapshot.docs.map((d) => ({ id: d.id, ...d.data() })))
    } catch (error) {
      setErro('Erro ao buscar carros: ' + (error.code || error.message))
    } finally {
      setCarregando(false)
    }
  }

  
  useEffect(() => {
    buscarCarros()
  }, [])

  
  async function sair() {
    await signOut(auth)
  }

  
  function abrir(carro) {
    setSelecionado(carro)
    setModal(null)
    window.scrollTo(0, 0)
  }


  function voltar() {
    setSelecionado(null)
    setModal(null)
  }

  // Registra a compra (a lógica fica em carrosService.js). Se der erro, a janela de pagamento mostra a mensagem.
  async function comprar(formaPagamento) {
    await comprarCarro(selecionado.id, formaPagamento)

    
    const venda = { status: 'vendido' }
    setSelecionado({ ...selecionado, ...venda })
    setCarros(carros.map((c) => (c.id === selecionado.id ? { ...c, ...venda } : c)))
  }

  
  if (selecionado) {
    // Só dá para financiar e comprar carros disponíveis
    const disponivel = (selecionado.status || 'disponivel') === 'disponivel'

    return (
      <div className="cliente">
        <div className="cliente-detalhe">
          <CarroCard carro={selecionado} detalhado>
            <button disabled={!disponivel} onClick={() => setModal('financiamento')}>
              Financiamento
            </button>
            <button disabled={!disponivel} onClick={() => setModal('pagamento')}>
              Comprar
            </button>
            <button onClick={voltar}>Voltar</button>
          </CarroCard>
        </div>

        {modal === 'pagamento' && (
          <ModalPagamento carro={selecionado} aoComprar={comprar} fechar={() => setModal(null)} />
        )}
        {modal === 'financiamento' && (
          <ModalFinanciamento carro={selecionado} fechar={() => setModal(null)} />
        )}
      </div>
    )
  }

  
  // Filtra pelo texto da pesquisa (marca, modelo, ano, cor, situação...)
  const texto = pesquisa.trim().toLowerCase()
  const filtrados = carros.filter((carro) => {
    const tudo = [carro.marca, carro.modelo, carro.ano, carro.motorizacao, carro.cor,
      carro.combustivel, carro.condicao, carro.descricao, situacaoDe(carro)].join(' ').toLowerCase()
    return tudo.includes(texto)
  })

  return (
    <div className="cliente">
    
      <div className="cliente-topo">
        <p className="cliente-boasvindas">Bem-vindo, {usuario.displayName || usuario.email}!</p>

        <div className="cliente-pesquisa">
          <input
            type="text"
            placeholder="Pesquisar"
            value={pesquisa}
            onChange={(e) => setPesquisa(e.target.value)}
          />
          <span>🔍</span>
        </div>

        <button className="cliente-sair" onClick={sair}>Sair</button>
      </div>

      {erro && <p className="cliente-erro">{erro}</p>}
      {carregando && <p>Carregando...</p>}
      {!carregando && carros.length === 0 && <p>Nenhum carro cadastrado ainda.</p>}
      {!carregando && carros.length > 0 && filtrados.length === 0 && <p>Nenhum carro encontrado.</p>}

      
      <div className="cliente-grade">
        {filtrados.map((carro) => (
          <CarroCard key={carro.id} carro={carro} aoClicar={() => abrir(carro)} />
        ))}
      </div>
    </div>
  )
}

export default Cliente