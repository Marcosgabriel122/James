import { useState } from 'react'
import { createUserWithEmailAndPassword, updateProfile } from 'firebase/auth'
import { doc, setDoc, serverTimestamp } from 'firebase/firestore'
import { auth, db } from '../firebaseConection'
import '../styles/Cadastro.css'

function Cadastro({ concluido, irParaLogin }) {
  const [nome, setNome] = useState('')
  const [email, setEmail] = useState('')
  const [senha, setSenha] = useState('')
  const [erro, setErro] = useState('')

  // Cria a conta no Firebase Authentication, guarda o nome e registra o usuário como "cliente"
  async function criarConta(e) {
    e.preventDefault()
    setErro('')

    try {
    
      const resultado = await createUserWithEmailAndPassword(auth, email, senha)

      
      await updateProfile(resultado.user, { displayName: nome })

      
  
      await setDoc(doc(db, 'usuarios', resultado.user.uid), {
        nome: nome,
        email: email,
        papel: 'cliente',
        criadoEm: serverTimestamp(),
      })

  
      concluido()
    } catch (error) {
      if (error.code === 'auth/weak-password') {
        setErro('A senha precisa ter pelo menos 6 caracteres')
      } else if (error.code === 'auth/email-already-in-use') {
        setErro('Esse e-mail já está em uso')
      } else if (error.code === 'auth/invalid-email') {
        setErro('E-mail inválido')
      } else if (error.code === 'permission-denied') {
        setErro('Conta criada, mas sem permissão para salvar o perfil. Confira as regras do Firestore.')
      } else {
        setErro('Erro ao criar conta: ' + (error.code || error.message))
      }
    }
  }

  return (
    <div className="cadastro">
      <h1>Criar conta</h1>

      {erro && <p className="cadastro-erro">{erro}</p>}

      <form onSubmit={criarConta}>
        <label htmlFor="nome">Nome</label>
        <input type="text" id="nome" value={nome} onChange={(e) => setNome(e.target.value)} required />

        <label htmlFor="email">E-mail</label>
        <input type="email" id="email" value={email} onChange={(e) => setEmail(e.target.value)} required />

        <label htmlFor="senha">Senha</label>
        <input type="password" id="senha" value={senha} onChange={(e) => setSenha(e.target.value)} required />

        <button type="submit">Criar conta</button>
      </form>

      <p>
        Já tem conta? <button onClick={irParaLogin}>Voltar ao login</button>
      </p>
    </div>
  )
}

export default Cadastro