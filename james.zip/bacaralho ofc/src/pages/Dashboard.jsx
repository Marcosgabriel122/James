import { useState, useEffect } from 'react'
import { signOut } from 'firebase/auth'
import { collection, getDocs } from 'firebase/firestore'
import { auth, db } from '../firebaseConection'
import CadastroCarro from './CadastroCarro'
import VerCarros from './VerCarros'
import Relatorio from './Relatorio'
import '../styles/Dashboard.css'

// Título mostrado na barra do topo (que só aparece no celular)
const titulos = {
  inicio: 'Início',
  cadastro: 'Cadastro',
  carros: 'Carros cadastrados',
  relatorio: 'Relatório de vendas',
}

function Dashboard({ usuario }) {

  const [tela, setTela] = useState('inicio')

  // No celular o menu é uma gaveta: true = aberta, false = fechada
  const [menuAberto, setMenuAberto] = useState(false)

  
  const [contagem, setContagem] = useState(null)
  const [erro, setErro] = useState('')

  // Toda vez que a tela inicial aparece (ao abrir ou ao voltar de outra tela),
  
  useEffect(() => {
    if (tela !== 'inicio') {
      return
    }

    async function contar() {
      try {
        const snapshot = await getDocs(collection(db, 'carros'))

        let disponiveis = 0
        let indisponiveis = 0
        let revisao = 0
        let vendidos = 0

        snapshot.docs.forEach((d) => {
          
          const status = d.data().status || 'disponivel'

          if (status === 'vendido') {
            vendidos += 1
          } else if (status === 'indisponivel') {
            indisponiveis += 1
          } else if (status === 'revisao') {
            revisao += 1
          } else {
            disponiveis += 1
          }
        })

        setContagem({ cadastrados: snapshot.size, disponiveis, indisponiveis, revisao, vendidos })
        setErro('')
      } catch (error) {
        setErro('Erro ao carregar os números: ' + (error.code || error.message))
      }
    }

    contar()
  }, [tela])


  const numeros = contagem || {
    cadastrados: '...',
    disponiveis: '...',
    indisponiveis: '...',
    revisao: '...',
    vendidos: '...',
  }

  
  async function sair() {
    await signOut(auth)
  }

  
  function irPara(nome) {
    setTela(nome)
    setMenuAberto(false)
  }

  
  function classeDe(nome) {
    return tela === nome ? 'ativo' : ''
  }

  return (
    <div className="dashboard">
      {/* Fundo escuro atrás da gaveta (celular): clicar nele fecha o menu */}
      {menuAberto && <div className="dashboard-fundo" onClick={() => setMenuAberto(false)}></div>}

      
      <div className={menuAberto ? 'dashboard-menu aberto' : 'dashboard-menu'}>
        <button className={classeDe('inicio')} onClick={() => irPara('inicio')}>Início</button>
        <button className={classeDe('cadastro')} onClick={() => irPara('cadastro')}>Cadastro</button>
        <button className={classeDe('carros')} onClick={() => irPara('carros')}>Ver carros cadastrados</button>
        <button className={classeDe('relatorio')} onClick={() => irPara('relatorio')}>Relatório de vendas</button>
        <button className="dashboard-sair" onClick={sair}>Sair</button>
      </div>

      <div className="dashboard-principal">
        {/* Barra do topo: só aparece no celular, com o botão que abre o menu */}
        <div className="dashboard-topo">
          <button className="dashboard-hamburguer" onClick={() => setMenuAberto(true)} aria-label="Abrir menu">
            ☰
          </button>
          <strong>{titulos[tela]}</strong>
        </div>

        {/* Conteúdo: muda conforme o botão clicado */}
        <div className="dashboard-conteudo">
          {tela === 'inicio' && (
            <div>
              <p className="dashboard-boasvindas">Bem-vindo, {usuario.displayName || usuario.email}</p>

              {erro && <p className="dashboard-erro">{erro}</p>}

              <div className="dashboard-cards">
                <div className="card">
                  <span className="card-numero">{numeros.cadastrados}</span>
                  <span className="card-texto">carros cadastrados</span>
                </div>
                <div className="card">
                  <span className="card-numero">{numeros.disponiveis}</span>
                  <span className="card-texto">carros disponíveis</span>
                </div>
                <div className="card">
                  <span className="card-numero">{numeros.indisponiveis}</span>
                  <span className="card-texto">carros não disponíveis</span>
                </div>
                <div className="card">
                  <span className="card-numero">{numeros.revisao}</span>
                  <span className="card-texto">carros em revisão</span>
                </div>
                <div className="card">
                  <span className="card-numero">{numeros.vendidos}</span>
                  <span className="card-texto">carros vendidos</span>
                </div>
              </div>
            </div>
          )}

          {tela === 'cadastro' && <CadastroCarro usuario={usuario} voltar={() => setTela('inicio')} />}
          {tela === 'carros' && <VerCarros usuario={usuario} />}
          {tela === 'relatorio' && <Relatorio />}
        </div>
      </div>
    </div>
  )
}

export default Dashboard