import { useState, useEffect } from 'react'
import { collection, getDocs, query, orderBy } from 'firebase/firestore'
import { db } from '../firebaseConection'
import { situacaoDe } from '../status'
import { excluirCarro } from '../carrosService'
import CadastroCarro from './CadastroCarro'
import '../styles/VerCarros.css'


function VerCarros({ usuario }) {
  const [carros, setCarros] = useState([])        
  const [pesquisa, setPesquisa] = useState('')    
  const [carregando, setCarregando] = useState(true)
  const [erro, setErro] = useState('')
  const [editando, setEditando] = useState(null)  

  
  async function buscarCarros() {
    setErro('')
    try {
      const consulta = query(collection(db, 'carros'), orderBy('criadoEm', 'asc'))
      const snapshot = await getDocs(consulta)
      
      setCarros(snapshot.docs.map((d) => ({ id: d.id, ...d.data() })))
    } catch (error) {
      setErro('Erro ao buscar carros: ' + (error.code || error.message))
    } finally {
      setCarregando(false)
    }
  }


  useEffect(() => {
    buscarCarros()
  }, [])

  
  async function deletar(carro) {
    if (!window.confirm('Deletar ' + carro.marca + ' ' + carro.modelo + '?')) {
      return
    }

    try {
      await excluirCarro(carro.id)
      setCarros(carros.filter((c) => c.id !== carro.id))
    } catch (error) {
      setErro('Erro ao deletar: ' + (error.code || error.message))
    }
  }


  function voltarDaEdicao() {
    setEditando(null)
    buscarCarros()
  }

  // Modo edição: mostra o formulário de cadastro preenchido com o carro escolhido
  if (editando) {
    return <CadastroCarro usuario={usuario} carro={editando} voltar={voltarDaEdicao} />
  }

  // Filtra pelo texto da pesquisa (a situação também entra: dá para pesquisar "revisão")
  const texto = pesquisa.trim().toLowerCase()
  const filtrados = carros.filter((carro) => {
    const tudo = [carro.marca, carro.modelo, carro.ano, carro.motorizacao, carro.cor,
      carro.combustivel, carro.condicao, carro.descricao, situacaoDe(carro)].join(' ').toLowerCase()
    return tudo.includes(texto)
  })

  return (
    <div>
      <div className="lista-topo">
        <h1>Carros cadastrados</h1>

        <div className="lista-pesquisa">
          <input
            type="text"
            placeholder="Pesquisa"
            value={pesquisa}
            onChange={(e) => setPesquisa(e.target.value)}
          />
          <span>🔍</span>
        </div>
      </div>

      {erro && <p className="lista-erro">{erro}</p>}
      {carregando && <p>Carregando...</p>}
      {!carregando && carros.length === 0 && <p>Nenhum carro cadastrado ainda.</p>}
      {!carregando && carros.length > 0 && filtrados.length === 0 && <p>Nenhum carro encontrado.</p>}

      {filtrados.map((carro) => (
        <div className="lista-item" key={carro.id}>
          <strong className="lista-titulo">{carro.marca} {carro.modelo}</strong>

          <div className="lista-info">
            <p>
              Ano: {carro.ano} | Motorização: {carro.motorizacao} | Cor: {carro.cor} | Combustível: {carro.combustivel}
            </p>
            <p>
              Quilometragem: {Number(carro.quilometragem).toLocaleString('pt-BR')} km | Condição: {carro.condicao}
            </p>
            <p>
              Preço: {Number(carro.preco).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })} | Situação: {situacaoDe(carro)}
            </p>
            {carro.descricao && <p>Obs.: {carro.descricao}</p>}
          </div>

          <div className="lista-acoes">
            <button onClick={() => setEditando(carro)}>Editar</button>
            <button onClick={() => deletar(carro)}>Deletar</button>
          </div>
        </div>
      ))}
    </div>
  )
}

export default VerCarros