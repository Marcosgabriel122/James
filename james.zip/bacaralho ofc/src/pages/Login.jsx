import { useState } from 'react'
import { signInWithEmailAndPassword } from 'firebase/auth'
import { auth } from '../firebaseConection'
import '../styles/Login.css'

function Login({ irParaCadastro }) {
  const [email, setEmail] = useState('')
  const [senha, setSenha] = useState('')
  const [erro, setErro] = useState('')

  // Faz o login com e-mail e senha no Firebase Authentication
  async function entrar(e) {
    e.preventDefault() // evita recarregar a página ao enviar o formulário
    setErro('')

    try {
      await signInWithEmailAndPassword(auth, email, senha)
      // Não precisa redirecionar: o App percebe o login (onAuthStateChanged) e abre o Dashboard
    } catch (error) {
      if (error.code === 'auth/invalid-credential' || error.code === 'auth/invalid-email') {
        setErro('E-mail ou senha incorretos')
      } else if (error.code === 'auth/too-many-requests') {
        setErro('Muitas tentativas, tente novamente mais tarde')
      } else {
        setErro('Erro ao entrar: ' + error.code)
      }
    }
  }

  return (
    <div className="login">
      <h1>Login</h1>

      {erro && <p className="login-erro">{erro}</p>}

      <form onSubmit={entrar}>
        <label htmlFor="email">E-mail</label>
        <input type="email" id="email" value={email} onChange={(e) => setEmail(e.target.value)} required />

        <label htmlFor="senha">Senha</label>
        <input type="password" id="senha" value={senha} onChange={(e) => setSenha(e.target.value)} required />

        <button type="submit">Entrar</button>
      </form>

      <p>
        Não tem conta? <button onClick={irParaCadastro}>Criar conta</button>
      </p>
    </div>
  )
}

export default Login
