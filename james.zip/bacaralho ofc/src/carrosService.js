import {
  collection, doc, getDoc, addDoc, updateDoc, deleteDoc, runTransaction, serverTimestamp,
} from 'firebase/firestore'
import { auth, db } from './firebaseConection'



// Lê o papel do usuário logado ('admin', 'usuario' ou 'cliente')
async function papelAtual() {
  const user = auth.currentUser
  if (!user) throw new Error('Você precisa estar logado.')
  const snap = await getDoc(doc(db, 'usuarios', user.uid))
  return snap.exists() ? snap.data().papel : 'cliente'
}

// Só admin e usuário gerenciam carros
async function exigirEquipe() {
  const papel = await papelAtual()
  if (papel !== 'admin' && papel !== 'usuario') {
    throw new Error('Sem permissão: apenas a equipe pode gerenciar carros.')
  }
}

export async function criarCarro(dados) {
  await exigirEquipe()
  return addDoc(collection(db, 'carros'), {
    ...dados,
    criadoPor: auth.currentUser.uid,
    criadoEm: serverTimestamp(),
  })
}

export async function atualizarCarro(id, dados) {

  
  await exigirEquipe()
  return updateDoc(doc(db, 'carros', id), { ...dados, atualizadoEm: serverTimestamp() })
}

export async function excluirCarro(id) {
  await exigirEquipe()
  return deleteDoc(doc(db, 'carros', id))
}


// cria a venda e marca o carro como vendido.
export async function comprarCarro(carroId, formaPagamento) {
  const user = auth.currentUser
  if (!user) throw new Error('Você precisa estar logado.')

  const carroRef = doc(db, 'carros', carroId)
  const vendaRef = doc(collection(db, 'vendas'))

  await runTransaction(db, async (transacao) => {
    const atual = await transacao.get(carroRef)

    if (!atual.exists() || (atual.data().status || 'disponivel') !== 'disponivel') {
      throw new Error('Esse carro não está mais disponível.')
    }

    const carro = atual.data()

    transacao.set(vendaRef, {
      carroId,
      marca: carro.marca,
      modelo: carro.modelo,
      ano: carro.ano,
      motorizacao: carro.motorizacao,
      cor: carro.cor,
      combustivel: carro.combustivel,
      quilometragem: carro.quilometragem,
      condicao: carro.condicao,
      preco: carro.preco,
      compradorId: user.uid,
      compradorNome: user.displayName || '',
      compradorEmail: user.email,
      formaPagamento,
      vendidoEm: serverTimestamp(),
    })

    transacao.update(carroRef, {
      status: 'vendido',
      vendidoEm: serverTimestamp(),
      vendaId: vendaRef.id,
    })
  })
}
