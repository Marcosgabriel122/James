// Nomes das situações do carro, usados em mais de uma página.
// A chave é o que fica salvo no Firestore; o valor é o texto mostrado na tela.
export const SITUACOES = {
  disponivel: 'Disponível',
  indisponivel: 'Não disponível',
  revisao: 'Em revisão',
  vendido: 'Vendido', // não é escolhido no formulário: fica reservado para quando a venda for registrada
}

// Devolve o texto da situação do carro (carros antigos sem o campo contam como disponíveis)
export function situacaoDe(carro) {
  return SITUACOES[carro.status] || 'Disponível'
}