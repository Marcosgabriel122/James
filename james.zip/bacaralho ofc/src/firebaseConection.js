import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";


const firebaseConfig = {
  apiKey: "AIzaSyBxiZ1FI58abZ8rB4MZWQDljEF6fcrKbBc",
  authDomain: "james-at-3.firebaseapp.com",
  projectId: "james-at-3",
  storageBucket: "james-at-3.firebasestorage.app",
  messagingSenderId: "787338708623",
  appId: "1:787338708623:web:e0ac7921751cbbfc3f12fa",
  measurementId: "G-9CNR0PRMJZ"
};


const app = initializeApp(firebaseConfig);

const db = getFirestore(app); 
const auth = getAuth(app);    

export { db, auth };
