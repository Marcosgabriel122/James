import { useState } from 'react'
import Modal from './Modal'


function dinheiro(valor) {
  return Number(valor || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
}


const PARCELAS = Array.from({ length: 48 }, (_, i) => i + 1)



function ModalFinanciamento({ carro, fechar }) {
  const [parcelas, setParcelas] = useState(12) 

  const preco = Number(carro.preco)

  return (
    <Modal titulo="Financiamento" fechar={fechar}>
      <p>{carro.marca} {carro.modelo}</p>
      <p className="modal-total">Valor do carro: {dinheiro(preco)}</p>

      <label htmlFor="parcelas">Número de parcelas (até 48x, sem juros)</label>
      <select id="parcelas" value={parcelas} onChange={(e) => setParcelas(Number(e.target.value))}>
        {PARCELAS.map((n) => (
          <option key={n} value={n}>
            {n}x de {dinheiro(preco / n)}
          </option>
        ))}
      </select>

      
      <div className="modal-resumo">
        <strong>{parcelas}x de {dinheiro(preco / parcelas)}</strong>
        <span>sem juros | Total: {dinheiro(preco)}</span>
      </div>

      <p className="modal-aviso">Isto é apenas uma simulação.</p>

      <div className="modal-botoes">
        <button type="button" onClick={fechar}>Fechar</button>
      </div>
    </Modal>
  )
}

export default ModalFinanciamento