import '../styles/Modal.css'



function Modal({ titulo, fechar, children }) {
  return (
    <div className="modal-fundo" onClick={fechar}>
    
      <div className="modal-caixa" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true">
        <div className="modal-topo">
          <h2>{titulo}</h2>
          <button className="modal-x" onClick={fechar} aria-label="Fechar">✕</button>
        </div>

        {children}
      </div>
    </div>
  )
}

export default Modal