import { situacaoDe } from '../status'
import '../styles/CarroCard.css'

function CarroCard({ carro, aoClicar, detalhado, children }) {
  const preco = Number(carro.preco).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
  const quilometragem = Number(carro.quilometragem).toLocaleString('pt-BR') + ' km'

  
  const disponivel = (carro.status || 'disponivel') === 'disponivel'

  
  if (detalhado) {
    
    const campos = [
      ['Marca', carro.marca],
      ['Modelo', carro.modelo],
      ['Ano', carro.ano],
      ['Motorização', carro.motorizacao],
      ['Quilometragem', quilometragem],
      ['Combustível', carro.combustivel],
      ['Cor', carro.cor],
      ['Condição', carro.condicao],
      ['Situação', situacaoDe(carro)],
    ]

    return (
      <div className="carro-detalhe">
        <p className="carro-detalhe-preco">Preço: {preco}</p>

        {campos.map(([rotulo, valor]) => (
          <p className="carro-detalhe-linha" key={rotulo}>
            <strong>{rotulo}:</strong> {valor}
          </p>
        ))}

        <div className="carro-detalhe-descricao">
          <strong>Descrição</strong>
          <p>{carro.descricao || 'Sem descrição.'}</p>
        </div>

        
        <div className="carro-detalhe-botoes">{children}</div>
      </div>
    )
  }

  
  let classe = 'carro-card'
  if (aoClicar) {
    classe += ' clicavel'
  }
  if (!disponivel) {
    classe += ' indisponivel'
  }

  
  function teclar(e) {
    if (aoClicar && e.key === 'Enter') {
      aoClicar()
    }
  }

  return (
    <div
      className={classe}
      onClick={aoClicar}
      onKeyDown={teclar}
      role={aoClicar ? 'button' : undefined}
      tabIndex={aoClicar ? 0 : undefined}
    >
      <span className={disponivel ? 'carro-card-situacao' : 'carro-card-situacao fora'}>
        {situacaoDe(carro)}
      </span>

      <h2 className="carro-card-titulo">{carro.marca} {carro.modelo}</h2>
      <p className="carro-card-preco">{preco}</p>

      <p>Ano: {carro.ano} | {quilometragem}</p>
      <p>Motorização: {carro.motorizacao} | {carro.combustivel}</p>
      <p>Cor: {carro.cor} | Condição: {carro.condicao}</p>
    </div>
  )
}

export default CarroCard