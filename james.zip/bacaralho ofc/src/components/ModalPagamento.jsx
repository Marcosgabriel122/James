import { useState } from 'react'
import Modal from './Modal'


const FORMAS = ['Pix', 'Cartão de crédito', 'Cartão de débito', 'Boleto']


function dinheiro(valor) {
  return Number(valor || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
}



function ModalPagamento({ carro, aoComprar, fechar }) {
  const [forma, setForma] = useState('')          
  const [comprando, setComprando] = useState(false) 
  const [comprado, setComprado] = useState(false)   
  const [erro, setErro] = useState('')

  
  async function confirmar() {
    setErro('')
    setComprando(true)

    try {
    
      await new Promise((resolve) => setTimeout(resolve, 1500))

      await aoComprar(forma)
      setComprado(true)
    } catch (error) {
      if (error.code === 'permission-denied') {
        setErro('nao foi possuível realizar essa compra')
      } else {
        setErro(error.message)
      }
    } finally {
      setComprando(false)
    }
  }


  if (comprado) {
    return (
      <Modal titulo="Compra realizada!" fechar={fechar}>
        <p className="modal-sucesso">
          Parabéns! Você comprou o {carro.marca} {carro.modelo} por {dinheiro(carro.preco)} ({forma}).
        </p>
        <p className="modal-aviso">Esta é uma compra simulada: nenhum pagamento real foi feito.</p>
        <div className="modal-botoes">
          <button onClick={fechar}>Fechar</button>
        </div>
      </Modal>
    )
  }


  return (
    <Modal titulo="Forma de pagamento" fechar={fechar}>
      <p>{carro.marca} {carro.modelo}</p>
      <p className="modal-total">Total: {dinheiro(carro.preco)}</p>

      <div className="modal-opcoes">
        {FORMAS.map((nome) => (
          <button
            key={nome}
            className={forma === nome ? 'modal-opcao ativa' : 'modal-opcao'}
            onClick={() => setForma(nome)}
            disabled={comprando}
          >
            {nome}
          </button>
        ))}
      </div>

      {erro && <p className="modal-erro">{erro}</p>}

      <div className="modal-botoes">
        <button type="button" onClick={confirmar} disabled={!forma || comprando} className="modal-principal">
          {comprando ? 'Processando...' : 'Comprar'}
        </button>
        <button type="button" onClick={fechar} disabled={comprando}>Cancelar</button>
      </div>
    </Modal>
  )
}

export default ModalPagamento