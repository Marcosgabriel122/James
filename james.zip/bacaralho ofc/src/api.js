// Comunicação com a API (Node + MySQL). Substitui o Firebase.
// Tudo que o front manda/recebe da API passa por aqui.

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3333'

// ---------- Tradução entre o formato da tela e o formato da API ----------
// As telas continuam usando marca, modelo, preco, status...
// A API usa car_marca, car_modelo, car_preco, car_situacao...
// Estas funções convertem de um para o outro, para as telas quase não mudarem.

const SITUACAO_PARA_API = {
  disponivel: 'disponivel',
  indisponivel: 'nao_disponivel',
  revisao: 'em_revisao',
  vendido: 'vendido',
}
const SITUACAO_PARA_TELA = Object.fromEntries(
  Object.entries(SITUACAO_PARA_API).map(([tela, api]) => [api, tela])
)

const PAGAMENTO_PARA_API = {
  'Pix': 'pix',
  'Cartão de crédito': 'cartao_credito',
  'Cartão de débito': 'cartao_debito',
  'Boleto': 'boleto',
}
const PAGAMENTO_PARA_TELA = Object.fromEntries(
  Object.entries(PAGAMENTO_PARA_API).map(([tela, api]) => [api, tela])
)

// API -> tela
function carroParaTela(c) {
  return {
    id: c.car_id,
    marca: c.car_marca,
    modelo: c.car_modelo,
    ano: c.car_ano,
    motorizacao: c.car_motorizacao,
    cor: c.car_cor,
    combustivel: c.car_combustivel,
    quilometragem: c.car_quilometragem,
    condicao: c.car_condicao,
    preco: Number(c.car_preco), // o MySQL devolve o decimal como texto
    descricao: c.car_descricao,
    status: SITUACAO_PARA_TELA[c.car_situacao],
  }
}

// tela -> API
function carroParaApi(c) {
  return {
    car_marca: c.marca,
    car_modelo: c.modelo,
    car_ano: c.ano,
    car_motorizacao: c.motorizacao,
    car_cor: c.cor,
    car_combustivel: c.combustivel,
    car_quilometragem: c.quilometragem,
    car_condicao: c.condicao,
    car_preco: c.preco,
    car_descricao: c.descricao,
    // "vendido" só muda pela compra; ao editar um carro vendido, a situação não é enviada
    ...(c.status !== 'vendido' && { car_situacao: SITUACAO_PARA_API[c.status] }),
  }
}

// venda da API -> formato que o Relatório já usava
function vendaParaTela(v) {
  return {
    ...carroParaTela(v.carro),
    id: v.venda_id,
    preco: Number(v.venda_valor), // preço no momento da venda
    compradorNome: v.user.user_name,
    compradorEmail: v.user.user_email,
    formaPagamento: PAGAMENTO_PARA_TELA[v.venda_forma_pagamento],
    vendidoEm: v.createAt,
  }
}

// ---------- Chamada base ----------
async function requisicao(caminho, { metodo = 'GET', corpo } = {}) {
  const token = localStorage.getItem('token')

  let resposta
  try {
    resposta = await fetch(API_URL + caminho, {
      method: metodo,
      headers: {
        'Content-Type': 'application/json',
        // o token prova para a API quem está logado
        ...(token && { Authorization: 'Bearer ' + token }),
      },
      body: corpo ? JSON.stringify(corpo) : undefined,
    })
  } catch {
    throw new Error('Não foi possível conectar com a API. Ela está rodando?')
  }

  const dados = await resposta.json().catch(() => null)

  if (!resposta.ok) {
    // token vencido ou inválido no meio do uso: apaga e volta para o login
    if (resposta.status === 401 && token) {
      localStorage.removeItem('token')
      window.location.reload()
    }
    // erro de validação (zod): junta as mensagens de cada campo
    if (dados?.details?.length) {
      throw new Error(dados.details.map((d) => d.mensagem).join(' '))
    }
    throw new Error(dados?.error || 'Erro ao falar com o servidor.')
  }

  return dados
}

// ---------- Conta e sessão ----------
export function temToken() {
  return Boolean(localStorage.getItem('token'))
}

// Faz login, guarda o token e devolve os dados do usuário
export async function entrar(email, senha) {
  const dados = await requisicao('/session', {
    metodo: 'POST',
    corpo: { user_email: email, user_password: senha },
  })
  localStorage.setItem('token', dados.token)
  const { token, ...usuario } = dados
  return usuario // { user_id, user_name, user_email, user_type }
}

// Cria conta de cliente (a API força o tipo "cliente")
export function cadastrar(nome, email, senha) {
  return requisicao('/signup', {
    metodo: 'POST',
    corpo: { user_name: nome, user_email: email, user_password: senha },
  })
}

// Quem é o usuário do token salvo? (usado quando o app abre)
export function usuarioAtual() {
  return requisicao('/me')
}

export function sair() {
  localStorage.removeItem('token')
}

// ---------- Carros ----------
export async function listarCarrosApi() {
  const carros = await requisicao('/carros')
  return carros.map(carroParaTela)
}

export function criarCarroApi(dados) {
  return requisicao('/carros', { metodo: 'POST', corpo: carroParaApi(dados) })
}

export function atualizarCarroApi(id, dados) {
  return requisicao('/carros/' + id, { metodo: 'PATCH', corpo: carroParaApi(dados) })
}

export function excluirCarroApi(id) {
  return requisicao('/carros/' + id, { metodo: 'DELETE' })
}

// ---------- Vendas ----------
export function comprarCarroApi(carroId, formaPagamento) {
  return requisicao('/vendas', {
    metodo: 'POST',
    corpo: { car_id: carroId, venda_forma_pagamento: PAGAMENTO_PARA_API[formaPagamento] },
  })
}

export async function listarVendasApi() {
  const vendas = await requisicao('/vendas')
  return vendas.map(vendaParaTela)
}
